import { CreateMLCEngine } from 'https://esm.run/@mlc-ai/web-llm';
const $ = id => document.getElementById(id);
const MODEL_ID = 'Qwen2.5-0.5B-Instruct-q4f16_1-MLC';
let engine = null, resumeText = '', transcript = [], currentQuestion = '', started = false, ended = false, recognition = null, listening = false, questionNumber = 0, startedAt = 0;
const MAX_QUESTIONS = () => Math.max(3, Math.min(12, Math.round(Number($('duration').value) / 2)));
function setStatus(id, text, ok=false) { $(id).textContent = text; $(id).className = 'status' + (ok ? ' ok' : ''); }
function addMessage(who, text) {
  const empty = document.querySelector('.empty'); if (empty) empty.remove();
  const el = document.createElement('div'); el.className = 'message ' + (who === 'AI interviewer' ? 'ai' : '');
  const b = document.createElement('b'); b.textContent = who; const body = document.createElement('div'); body.textContent = text;
  el.append(b, body); $('messages').append(el); $('messages').scrollTop = $('messages').scrollHeight;
  transcript.push({speaker:who, text});
}
function speak(text) {
  if (!('speechSynthesis' in window)) return;
  window.speechSynthesis.cancel(); const utterance = new SpeechSynthesisUtterance(text); utterance.rate = 0.96; utterance.pitch = 1;
  const voices = window.speechSynthesis.getVoices(); const voice = voices.find(v => /^en(-|_)/i.test(v.lang) && /natural|google|microsoft/i.test(v.name)) || voices.find(v => /^en(-|_)/i.test(v.lang)); if (voice) utterance.voice = voice;
  utterance.onstart = () => { document.querySelector('.stage').classList.add('active'); $('speaker').textContent = 'Interviewer is speaking'; };
  utterance.onend = () => { document.querySelector('.stage').classList.remove('active'); $('speaker').textContent = 'Your turn to answer'; };
  window.speechSynthesis.speak(utterance);
}
function safeResume() { return resumeText.slice(0, 4200) || 'No resume uploaded. Ask general questions for the selected role.'; }
function recentTranscript() { return transcript.slice(-8).map(x => `${x.speaker}: ${x.text}`).join('\n').slice(-3500); }
async function generate(prompt, maxTokens=180) {
  if (!engine) throw new Error('Load the local AI model first.');
  const out = await engine.chat.completions.create({messages:[{role:'system',content:'You are a skilled, realistic job interviewer. Be concise, specific, fair, and professional. Ask one question at a time. Do not claim facts about the candidate that are not in their resume or answers.'},{role:'user',content:prompt}],temperature:0.65,max_tokens:maxTokens});
  return (out.choices?.[0]?.message?.content || '').trim().replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'');
}
$('resume').addEventListener('change', async e => {
  const file=e.target.files?.[0]; if(!file)return; $('file-label').textContent=file.name; setStatus('resume-status','Reading resume locally…');
  try {
    if(file.size>8*1024*1024) throw new Error('Please use a resume smaller than 8 MB.');
    if(file.name.toLowerCase().endsWith('.pdf')) { const pdf=await pdfjsLib.getDocument({data:await file.arrayBuffer()}).promise; const pages=[]; for(let i=1;i<=Math.min(pdf.numPages,20);i++){const p=await pdf.getPage(i);const c=await p.getTextContent();pages.push(c.items.map(x=>x.str).join(' '));} resumeText=pages.join('\n').slice(0,10000); }
    else if(file.name.toLowerCase().endsWith('.docx')) {const result=await mammoth.extractRawText({arrayBuffer:await file.arrayBuffer()});resumeText=result.value.slice(0,10000);}
    else throw new Error('Upload a PDF or DOCX file.');
    if(!resumeText.trim())throw new Error('No selectable text found. Try a text-based PDF or DOCX.'); setStatus('resume-status',`Resume ready · ${resumeText.length.toLocaleString()} characters extracted in this browser`,true);
  } catch(err){resumeText='';setStatus('resume-status',err.message);}
});
$('load-model').addEventListener('click', async()=>{
  if(engine)return; $('load-model').disabled=true; $('connection').textContent='Loading model…'; $('speaker').textContent='Preparing local AI'; setStatus('model-status','Checking WebGPU and loading model… this can take a while on the first visit.');
  try {
    if(!navigator.gpu) throw new Error('WebGPU is unavailable in this browser/device. Try the latest Chrome or Edge on a supported computer.');
    engine=await CreateMLCEngine(MODEL_ID,{initProgressCallback:p=>{const percent=Math.round((p.progress||0)*100);setStatus('model-status',p.text||`Downloading model: ${percent}%`);}});
    setStatus('model-status','Local AI model loaded. No API key or AI server is used.',true); $('connection').textContent='Local AI ready'; $('speaker').textContent='Your interviewer is ready'; $('subtitle').textContent='Start the interview when you are ready.'; $('start').disabled=false; $('mic').disabled=false;
  } catch(err){engine=null; $('load-model').disabled=false; $('connection').textContent='Model failed'; setStatus('model-status',`Could not load the local model: ${err.message}`); $('subtitle').textContent='Try the latest Chrome or Edge with WebGPU enabled.';}
});
$('start').addEventListener('click',async()=>{
  if(!engine||started)return; started=true;ended=false;questionNumber=0;startedAt=Date.now();transcript=[];$('messages').replaceChildren();$('start').disabled=true;$('end').disabled=false;$('submit-answer').disabled=true;$('evaluate').disabled=true;$('answer').value='';
  try { await askNext(true); $('mic').disabled=false; } catch(err){addMessage('System',`Could not generate a question: ${err.message}`);started=false;$('start').disabled=false;$('end').disabled=true;}
});
async function askNext(first=false, answer='') {
  questionNumber++; $('question-count').textContent=`QUESTION ${questionNumber}`; $('submit-answer').disabled=true;$('mic').disabled=true;$('answer').disabled=true; $('speaker').textContent='Thinking…'; $('subtitle').textContent='The local model is preparing your next question.';
  const prompt = first
    ? `Start a ${$('difficulty').value.toLowerCase()} difficulty interview for the role "${$('role').value}". Candidate resume:\n${safeResume()}\nAsk a short greeting and the first relevant interview question. Ask only one question. Do not give sample answers.`
    : `Interview role: ${$('role').value}. Difficulty: ${$('difficulty').value}. Candidate resume:\n${safeResume()}\nConversation so far:\n${recentTranscript()}\nLatest candidate answer: ${answer}\nDecide the most useful next question. If the answer is vague, incorrect, or mentions a claim/technology/project worth probing, ask one concise cross-question about it. Otherwise progress to a different resume- or role-relevant question. Never answer your own question. Ask exactly one question, no commentary or scoring.`;
  let q=await generate(prompt,180); if(!q)q='Could you tell me more about your experience and how it relates to this role?'; currentQuestion=q; addMessage('AI interviewer',q); $('subtitle').textContent=q; $('speaker').textContent='Your interviewer is asking'; speak(q); $('answer').disabled=false;$('submit-answer').disabled=false;$('mic').disabled=false;
}
function setupRecognition(){const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR)return null;const r=new SR();r.lang='en-IN';r.continuous=true;r.interimResults=true;r.onresult=e=>{let text='';for(let i=0;i<e.results.length;i++){text+=e.results[i][0].transcript+' ';} $('answer').value=text.trim();};r.onerror=e=>setStatus('voice-status',`Speech recognition issue: ${e.error}. You can type your answer instead.`);r.onend=()=>{listening=false;$('mic').textContent='🎙 Start microphone';document.querySelector('.stage').classList.remove('active');};return r;}
$('mic').addEventListener('click',()=>{if(!started)return;if(!recognition)recognition=setupRecognition();if(!recognition){setStatus('voice-status','Speech recognition is not supported here. Please type your answer.');return;}try{if(!listening){recognition.start();listening=true;$('mic').textContent='■ Stop microphone';setStatus('voice-status','Listening… speak clearly, then stop the microphone and submit your answer.',true);document.querySelector('.stage').classList.add('active');}else{recognition.stop();listening=false;$('mic').textContent='🎙 Start microphone';setStatus('voice-status','Microphone stopped. Review your transcript, then submit.');document.querySelector('.stage').classList.remove('active');}}catch(e){setStatus('voice-status','Microphone could not start. Check browser permissions or type your answer.');}});
$('submit-answer').addEventListener('click',async()=>{if(!started)return;const answer=$('answer').value.trim();if(!answer){setStatus('voice-status','Please speak or type an answer before submitting.');return;}if(listening&&recognition){recognition.stop();listening=false;}addMessage('You',answer);$('answer').value='';$('submit-answer').disabled=true;$('mic').disabled=true;
  if(questionNumber>=MAX_QUESTIONS()){ended=true;started=false;$('end').disabled=true;$('start').disabled=false;$('evaluate').disabled=false;$('speaker').textContent='Interview complete';$('subtitle').textContent='Your answers are ready for evaluation.';setStatus('voice-status','Interview completed. Generate your evaluation below.',true);return;}
  try{await askNext(false,answer);}catch(err){addMessage('System',`Could not generate follow-up: ${err.message}`);$('submit-answer').disabled=false;$('mic').disabled=false;}
});
$('end').addEventListener('click',()=>{if(listening&&recognition)recognition.stop();if('speechSynthesis'in window)window.speechSynthesis.cancel();document.querySelector('.stage').classList.remove('active');started=false;ended=true;$('end').disabled=true;$('start').disabled=false;$('submit-answer').disabled=true;$('mic').disabled=true;$('speaker').textContent='Session complete';$('subtitle').textContent='Your interview has ended. Generate your feedback below.';$('evaluate').disabled=!transcript.some(x=>x.speaker==='You');setStatus('voice-status','Interview ended.');});
$('evaluate').addEventListener('click',async()=>{if(!ended)return;$('evaluate').disabled=true;$('evaluate').textContent='Evaluating locally…';$('report-content').textContent='The on-device model is evaluating your answers. This can take a little while.';try{
  const prompt=`Evaluate this mock interview fairly for the role "${$('role').value}" at ${$('difficulty').value} difficulty. Resume:\n${safeResume()}\nTranscript:\n${transcript.map(x=>x.speaker+': '+x.text).join('\n').slice(-6000)}\nReturn plain text with these exact headings: OVERALL SCORE: [0-100]/100; SUMMARY:; TECHNICAL KNOWLEDGE: [0-100]/100; COMMUNICATION: [0-100]/100; PROBLEM SOLVING: [0-100]/100; RELEVANCE: [0-100]/100; STRENGTHS: (3 bullets); AREAS TO IMPROVE: (3 bullets); ANSWER FEEDBACK: (brief feedback for each candidate answer, with one example improvement where useful). Be honest, base scores on transcript evidence, and don't infer voice tone or body language.`;
  const report=await generate(prompt,700);renderReport(report||'The model did not return an evaluation. Please try again.');
 }catch(err){$('report-content').textContent=`Evaluation failed: ${err.message}`;}finally{$('evaluate').disabled=false;$('evaluate').textContent='Generate my evaluation';}});
function renderReport(text){const root=$('report-content');root.replaceChildren();const pre=document.createElement('pre');pre.className='local-report';pre.textContent=text;root.append(pre);}
