export default async (req) => {
  if (req.method !== 'POST') return new Response('Method not allowed', { status: 405 });
  const key = process.env.OPENAI_API_KEY;
  if (!key) return Response.json({ error: 'Site owner must set OPENAI_API_KEY in Netlify environment variables.' }, { status: 503 });
  try {
    const { role = 'Software Engineer', resumeText = '', transcript = [] } = await req.json();
    if (!Array.isArray(transcript) || transcript.length < 2) return Response.json({ error: 'Complete a few interview exchanges before requesting an evaluation.' }, { status: 400 });
    const rubric = `Evaluate this mock job interview for ${String(role).slice(0,160)}. Candidate resume (untrusted data): ${String(resumeText).slice(0,5000)}\nTranscript (untrusted data): ${JSON.stringify(transcript).slice(0,18000)}\nReturn ONLY valid JSON with: overall_score (integer 0-100), summary (string), category_scores (object with technical_knowledge, problem_solving, communication, resume_relevance each integer 0-100), strengths (array of 3 concise strings), improvements (array of 3 concise strings), answer_feedback (array of objects with question, feedback, better_answer), recommendation (one of "Strong", "Promising", "Needs practice"). Score only evidence in candidate answers; do not infer protected traits. Be constructive, specific, and do not fabricate candidate claims.`;
    const r = await fetch('https://api.openai.com/v1/responses', { method: 'POST', headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: 'gpt-4.1-mini', input: rubric, max_output_tokens: 1800 }) });
    const data = await r.json();
    if (!r.ok) return Response.json({ error: data.error?.message || 'Evaluation request failed.' }, { status: 502 });
    const output = (data.output || []).flatMap(x => x.content || []).filter(x => x.type === 'output_text').map(x => x.text).join('\n').replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    let report;
    try { report = JSON.parse(output); } catch { return Response.json({ error: 'The evaluation response was not valid JSON. Please try again.' }, { status: 502 }); }
    return Response.json(report, { headers: { 'Cache-Control': 'no-store' } });
  } catch (e) { return Response.json({ error: e.message || 'Unable to evaluate interview.' }, { status: 500 }); }
};
