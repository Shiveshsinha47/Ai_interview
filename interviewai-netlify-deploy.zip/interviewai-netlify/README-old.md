# InterviewAI — starter prototype

A local web prototype for a resume-aware, spoken AI interviewer. Includes a responsive dashboard, PDF/DOCX text extraction, and a browser WebRTC connection to the OpenAI Realtime API. The face is a CSS illustration, not a photorealistic talking avatar.

## Requirements
- Python 3.10+
- Node.js 18+
- An OpenAI API key with Realtime API access (API billing/usage is separate from ChatGPT subscriptions)

## Run on Windows
1. Extract this folder.
2. Open a terminal in `backend` and run:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   copy .env.example .env
   notepad .env
   ```
3. Put your API key after `OPENAI_API_KEY=` in `backend/.env`. Never put a standard API key in frontend code or share it.
4. Start the backend from `backend`:
   ```powershell
   uvicorn main:app --reload --host 127.0.0.1 --port 8000
   ```
5. In another terminal, open `frontend` and run:
   ```powershell
   npm install
   npm run dev
   ```
6. Open the local URL Vite prints (usually `http://127.0.0.1:5173`). Allow microphone access. Upload a PDF/DOCX resume, set the role, and start.

## Current scope and known limitations
- Real-time voice is wired through a backend-authenticated WebRTC session. The server key is not sent to the browser.
- Resume parsing extracts selectable PDF text and DOCX paragraphs. Scanned PDFs need OCR.
- The transcript uses available Realtime transcript events; exact event behavior can vary by API model/session configuration.
- The CSS face is a static illustrative avatar; there is no generated face video, lip-sync, or webcam recording in this starter.
- No login, database, persistent session history, audio recording, end-of-interview scoring, downloadable report, or production security/rate limits yet. Those are the next implementation phase.
- Treat resume text as private; this prototype sends the extracted resume context to the voice model during session setup.

## Troubleshooting
- `OPENAI_API_KEY is not configured`: ensure `.env` is in `backend/` and load it before launching. For convenience, add `from dotenv import load_dotenv; load_dotenv()` near the top of `main.py` before reading environment variables, or set the environment variable in PowerShell before starting uvicorn:
  ```powershell
  $env:OPENAI_API_KEY="your_key_here"
  uvicorn main:app --reload --host 127.0.0.1 --port 8000
  ```
- Browser microphone requires localhost or HTTPS.
- If API errors occur, check Realtime API access, billing, and the current official API documentation.
