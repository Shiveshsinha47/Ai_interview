# InterviewAI — Netlify deployment (no app storage)

This is a static site plus two Netlify serverless functions. It has **no database, user accounts, storage bucket, or persistent transcript/audio storage**. Resume parsing happens in the browser. Resume text and the live interview transcript are sent to the AI provider only to provide the requested interview/evaluation. The transcript remains in browser memory and is lost on refresh/close.

## Deploy to Netlify

1. Unzip this project.
2. In Netlify, choose **Add new site → Import an existing project** and connect the Git repository containing these files. Alternatively, use Netlify CLI from this folder (`npm install -g netlify-cli`, then `netlify deploy`).
3. Set the site root/base directory to the project root. `netlify.toml` already sets publish directory to `site` and functions directory to `netlify/functions`.
4. In **Site configuration → Environment variables**, add `OPENAI_API_KEY` with an API key from the OpenAI API platform. Do not put the key in `site/main.js`, HTML, or any public environment variable. Redeploy after adding it.
5. Open the deployed HTTPS URL, upload a text-based PDF or DOCX resume, allow microphone access, and start an interview.

## Features

- Resume text extraction for PDF/DOCX in the browser.
- Real-time spoken interviewer using WebRTC and OpenAI Realtime API.
- Adaptive questions/cross-questions using the selected role and resume.
- Browser-only transcript during the active page session.
- End-of-interview scoring via a serverless function: overall score, category scores, strengths, improvement areas, and answer feedback.
- No persistent storage or recording feature.

## Important limitations and privacy

- The site owner must provide and pay for API usage; a ChatGPT subscription does not automatically include API credits.
- Anyone can visit a public deployment and trigger API usage billed to the owner's API account. Before sharing widely, add rate limiting / abuse protection (for example Netlify rate limiting or a CAPTCHA) and monitor usage/budget limits. Never publish the API key.
- The resume is parsed locally, but its extracted text is sent to the AI service when an interview starts; the transcript is sent to the AI service for evaluation when the user requests it. This app itself does not persist it. Be transparent with users and obtain consent.
- The AI avatar is a CSS illustration, not a photorealistic video avatar. Voice is real-time audio. No audio/video recording is saved.
- Scanned/image-only PDFs may not yield selectable text. Upload a text-based PDF or DOCX.
- Third-party browser libraries are loaded from CDNs. For a stricter production deployment, vendor and pin those dependencies locally.

## Local preview

Install Node.js and Netlify CLI, then run `netlify dev` in this directory. Add `OPENAI_API_KEY` to a local `.env` file (do not commit it). Netlify Dev serves the site and functions together.
