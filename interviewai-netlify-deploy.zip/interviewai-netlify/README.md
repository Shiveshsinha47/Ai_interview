# InterviewAI — Free local AI / Netlify edition

This version does not require an OpenAI key, paid AI API, database, accounts, or server-side AI functions. The language model runs in each visitor's browser through WebLLM and WebGPU. The selected open-source model is `Qwen2.5-0.5B-Instruct-q4f16_1-MLC`.

## Deploy to Netlify

1. Replace the files in your connected GitHub repository with the contents of this folder, then commit and push. Or create a new repository and import it into Netlify.
2. Netlify build settings: publish directory `site`; no build command required. `netlify.toml` sets the publish directory.
3. Deploy. No `OPENAI_API_KEY` or other API secret is required. Remove the old `OPENAI_API_KEY` Netlify environment variable if you added one for the previous version; this version does not use it.
4. Open the HTTPS deployment in current Chrome or Edge on a WebGPU-capable computer. Click **Load free AI model** and wait for the model download and initialization. Then upload a PDF/DOCX resume, choose a role, and start the interview.

## How it works

- The model runs on the visitor's device; prompts, resume text, and interview transcript are sent to the local model in browser memory, not to an app backend.
- PDF/DOCX text extraction happens in the browser.
- Voice output uses the browser's speech synthesis.
- Speech recognition uses the browser Web Speech API when available. Some browsers/vendors may send speech to their own recognition service; users can type answers instead.
- The report is generated locally by the same small model.
- No accounts, database, persistent interview history, audio/video recording, or server-side AI function is included.

## Important limitations

- The first visit downloads the model and can consume several hundred MB of data; the browser may cache it for later visits.
- WebGPU is required for the chosen model. Compatible hardware and a current Chrome/Edge browser are recommended. Some devices/browsers will not work.
- A 0.5B parameter model is much smaller and less capable than hosted premium models. Interview questions and scoring may be less reliable, so describe scores as practice feedback, not hiring decisions.
- Speech recognition availability and privacy depend on the browser. Users can type their answers.
- Third-party libraries and model weights are downloaded from their public CDNs/model hosting the first time. A connection is needed to load them.
- The resume is not uploaded by this app, but users should be informed about browser speech-recognition behavior and external static asset/model downloads.

## Local preview

Because this uses ES modules and browser APIs, serve the `site` directory over localhost (for example `npx serve site`) rather than opening `index.html` directly. WebGPU works only in secure contexts such as HTTPS or localhost.
